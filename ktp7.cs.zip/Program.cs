﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Лабораторна робота №7");
        Console.WriteLine("Виконала студентка групи БІП-1-25 Атанасова Альбіна");

        int N;
        Console.WriteLine("Задайте розмір масиву (від 20 до 500)");
        N = int.Parse(Console.ReadLine());

        int[] arr = new int[N]; //Створюємо масив і заповнюємо рандомними числами
        Random rand = new Random();

        for (int i = 0; i < N; i++)
        {
            arr[i] = rand.Next(1, 51);
        }
        Console.WriteLine("\nЗгенерований масив: "); //Виведення масиву
        for (int i = 0; i < N; i++)
        {
            Console.Write(arr[i] + " ");

        }
        Console.WriteLine("\n");
      
        bool hasDuplicates = false; //Перевірка на повтор елементів
        for (int i = 0; i < N; i++)
        {
            for (int j = i + 1; j < N; j++)
            {
                if (arr[i] == arr[j])
                {
                    hasDuplicates = true;
                    break;
                }
            }
            if (hasDuplicates)
                break;
        }

        //Виведення результату
        if (hasDuplicates)
            Console.WriteLine("У масиві є елементи, що повторюються.");
        else
            Console.WriteLine("Усі елементи унікальні (повторів немає).");

    }
}